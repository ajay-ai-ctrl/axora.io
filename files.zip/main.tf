# SmartKhet — AWS Infrastructure (Terraform)
# ============================================
# Provisions: EKS Cluster, RDS Aurora PostgreSQL,
#             ElastiCache Redis, MSK Kafka, S3, ECR
# Region: ap-south-1 (Mumbai) — primary
# Run: terraform init && terraform plan && terraform apply

terraform {
  required_version = ">= 1.8.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = "~> 2.30"
    }
  }
  backend "s3" {
    bucket         = "smartkhet-terraform-state"
    key            = "prod/terraform.tfstate"
    region         = "ap-south-1"
    encrypt        = true
    dynamodb_table = "smartkhet-tf-locks"
  }
}

provider "aws" {
  region = var.aws_region
  default_tags {
    tags = {
      Project     = "SmartKhet"
      Environment = var.environment
      ManagedBy   = "Terraform"
      Team        = "Axora"
    }
  }
}

# ── Variables ─────────────────────────────────────────────────────────────────

variable "aws_region"    { default = "ap-south-1" }
variable "environment"   { default = "production" }
variable "cluster_name"  { default = "smartkhet-eks" }
variable "db_password"   { sensitive = true }
variable "eks_node_instance_types" {
  default = ["m5.xlarge", "m5.2xlarge"]
}
variable "eks_gpu_instance_types" {
  default = ["g4dn.xlarge"]
}

# ── Data Sources ───────────────────────────────────────────────────────────────

data "aws_availability_zones" "available" {
  state = "available"
}

# ── VPC ───────────────────────────────────────────────────────────────────────

resource "aws_vpc" "main" {
  cidr_block           = "10.0.0.0/16"
  enable_dns_hostnames = true
  enable_dns_support   = true
}

resource "aws_internet_gateway" "main" {
  vpc_id = aws_vpc.main.id
}

resource "aws_subnet" "public" {
  count                   = 3
  vpc_id                  = aws_vpc.main.id
  cidr_block              = "10.0.${count.index}.0/24"
  availability_zone       = data.aws_availability_zones.available.names[count.index]
  map_public_ip_on_launch = true
  tags = { Name = "smartkhet-public-${count.index}" }
}

resource "aws_subnet" "private" {
  count             = 3
  vpc_id            = aws_vpc.main.id
  cidr_block        = "10.0.${count.index + 10}.0/24"
  availability_zone = data.aws_availability_zones.available.names[count.index]
  tags = { Name = "smartkhet-private-${count.index}" }
}

resource "aws_nat_gateway" "main" {
  allocation_id = aws_eip.nat.id
  subnet_id     = aws_subnet.public[0].id
  depends_on    = [aws_internet_gateway.main]
}

resource "aws_eip" "nat" {
  domain = "vpc"
}

resource "aws_route_table" "private" {
  vpc_id = aws_vpc.main.id
  route {
    cidr_block     = "0.0.0.0/0"
    nat_gateway_id = aws_nat_gateway.main.id
  }
}

resource "aws_route_table_association" "private" {
  count          = 3
  subnet_id      = aws_subnet.private[count.index].id
  route_table_id = aws_route_table.private.id
}


# ── EKS Cluster ───────────────────────────────────────────────────────────────

resource "aws_eks_cluster" "main" {
  name     = var.cluster_name
  role_arn = aws_iam_role.eks_cluster.arn
  version  = "1.30"

  vpc_config {
    subnet_ids              = aws_subnet.private[*].id
    endpoint_private_access = true
    endpoint_public_access  = true
    public_access_cidrs     = ["0.0.0.0/0"]
  }

  enabled_cluster_log_types = ["api", "audit", "authenticator"]
  depends_on = [aws_iam_role_policy_attachment.eks_cluster_policy]
}

# General-purpose node group
resource "aws_eks_node_group" "general" {
  cluster_name    = aws_eks_cluster.main.name
  node_group_name = "smartkhet-general"
  node_role_arn   = aws_iam_role.eks_node.arn
  subnet_ids      = aws_subnet.private[*].id
  instance_types  = var.eks_node_instance_types

  scaling_config {
    desired_size = 5
    min_size     = 3
    max_size     = 50
  }

  update_config {
    max_unavailable = 1
  }

  labels = { role = "general" }

  lifecycle {
    ignore_changes = [scaling_config[0].desired_size]
  }

  depends_on = [
    aws_iam_role_policy_attachment.eks_worker_node_policy,
    aws_iam_role_policy_attachment.eks_cni_policy,
    aws_iam_role_policy_attachment.ecr_read_only,
  ]
}

# GPU node group for ML inference
resource "aws_eks_node_group" "gpu" {
  cluster_name    = aws_eks_cluster.main.name
  node_group_name = "smartkhet-gpu"
  node_role_arn   = aws_iam_role.eks_node.arn
  subnet_ids      = [aws_subnet.private[0].id]  # Single AZ for GPU spot
  instance_types  = var.eks_gpu_instance_types

  scaling_config {
    desired_size = 2
    min_size     = 1
    max_size     = 20
  }

  capacity_type = "SPOT"  # 60-70% cost saving on GPU instances

  labels = { role = "gpu", "node-type" = "gpu" }
  taint {
    key    = "nvidia.com/gpu"
    value  = "true"
    effect = "NO_SCHEDULE"
  }

  depends_on = [aws_eks_node_group.general]
}


# ── RDS Aurora PostgreSQL ─────────────────────────────────────────────────────

resource "aws_rds_cluster" "postgres" {
  cluster_identifier      = "smartkhet-aurora-pg"
  engine                  = "aurora-postgresql"
  engine_version          = "16.2"
  database_name           = "smartkhet"
  master_username         = "smartkhet_admin"
  master_password         = var.db_password
  vpc_security_group_ids  = [aws_security_group.rds.id]
  db_subnet_group_name    = aws_db_subnet_group.main.name
  storage_encrypted       = true
  kms_key_id              = aws_kms_key.rds.arn
  backup_retention_period = 14
  preferred_backup_window = "01:00-03:00"
  deletion_protection     = true

  serverlessv2_scaling_configuration {
    min_capacity = 0.5   # Minimum ACU (scales to 0 in off-peak)
    max_capacity = 64    # Maximum ACU for peak load
  }
}

resource "aws_rds_cluster_instance" "writer" {
  identifier         = "smartkhet-aurora-pg-writer"
  cluster_identifier = aws_rds_cluster.postgres.id
  instance_class     = "db.serverless"
  engine             = aws_rds_cluster.postgres.engine
  engine_version     = aws_rds_cluster.postgres.engine_version
}

resource "aws_rds_cluster_instance" "reader" {
  count              = 2
  identifier         = "smartkhet-aurora-pg-reader-${count.index}"
  cluster_identifier = aws_rds_cluster.postgres.id
  instance_class     = "db.serverless"
  engine             = aws_rds_cluster.postgres.engine
  engine_version     = aws_rds_cluster.postgres.engine_version
}

resource "aws_db_subnet_group" "main" {
  name       = "smartkhet-db-subnet-group"
  subnet_ids = aws_subnet.private[*].id
}


# ── ElastiCache Redis ─────────────────────────────────────────────────────────

resource "aws_elasticache_replication_group" "redis" {
  replication_group_id       = "smartkhet-redis"
  description                = "SmartKhet Redis cluster"
  node_type                  = "cache.r6g.large"
  num_cache_clusters         = 3         # 1 primary + 2 replicas
  automatic_failover_enabled = true
  multi_az_enabled           = true
  engine_version             = "7.2"
  parameter_group_name       = "default.redis7"
  subnet_group_name          = aws_elasticache_subnet_group.main.name
  security_group_ids         = [aws_security_group.redis.id]
  at_rest_encryption_enabled = true
  transit_encryption_enabled = true
  port                       = 6379
}

resource "aws_elasticache_subnet_group" "main" {
  name       = "smartkhet-elasticache-subnet"
  subnet_ids = aws_subnet.private[*].id
}


# ── MSK Kafka ────────────────────────────────────────────────────────────────

resource "aws_msk_cluster" "kafka" {
  cluster_name           = "smartkhet-kafka"
  kafka_version          = "3.6.0"
  number_of_broker_nodes = 3

  broker_node_group_info {
    instance_type   = "kafka.m5.large"
    client_subnets  = aws_subnet.private[*].id
    storage_info {
      ebs_storage_info {
        volume_size = 500
      }
    }
    security_groups = [aws_security_group.kafka.id]
  }

  encryption_info {
    encryption_in_transit {
      client_broker = "TLS"
      in_cluster    = true
    }
  }

  configuration_info {
    arn      = aws_msk_configuration.main.arn
    revision = aws_msk_configuration.main.latest_revision
  }
}

resource "aws_msk_configuration" "main" {
  name = "smartkhet-kafka-config"
  server_properties = <<-EOF
    auto.create.topics.enable=false
    log.retention.hours=168
    log.segment.bytes=536870912
    default.replication.factor=3
    min.insync.replicas=2
    num.partitions=6
  EOF
}


# ── S3 Buckets ─────────────────────────────────────────────────────────────────

resource "aws_s3_bucket" "images" {
  bucket        = "smartkhet-images-${var.environment}"
  force_destroy = false
}

resource "aws_s3_bucket_server_side_encryption_configuration" "images" {
  bucket = aws_s3_bucket.images.id
  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
  }
}

resource "aws_s3_bucket_lifecycle_configuration" "images" {
  bucket = aws_s3_bucket.images.id
  rule {
    id     = "expire-old-images"
    status = "Enabled"
    expiration { days = 365 }
    filter { prefix = "disease-images/" }
  }
}

resource "aws_s3_bucket" "ml_artifacts" {
  bucket = "smartkhet-ml-artifacts-${var.environment}"
}


# ── KMS Keys ───────────────────────────────────────────────────────────────────

resource "aws_kms_key" "rds" {
  description             = "SmartKhet RDS encryption key"
  deletion_window_in_days = 30
  enable_key_rotation     = true
}


# ── Security Groups ───────────────────────────────────────────────────────────

resource "aws_security_group" "rds" {
  name   = "smartkhet-rds-sg"
  vpc_id = aws_vpc.main.id
  ingress {
    from_port       = 5432
    to_port         = 5432
    protocol        = "tcp"
    security_groups = [aws_security_group.eks_nodes.id]
  }
  egress { from_port = 0; to_port = 0; protocol = "-1"; cidr_blocks = ["0.0.0.0/0"] }
}

resource "aws_security_group" "redis" {
  name   = "smartkhet-redis-sg"
  vpc_id = aws_vpc.main.id
  ingress {
    from_port       = 6379
    to_port         = 6379
    protocol        = "tcp"
    security_groups = [aws_security_group.eks_nodes.id]
  }
  egress { from_port = 0; to_port = 0; protocol = "-1"; cidr_blocks = ["0.0.0.0/0"] }
}

resource "aws_security_group" "kafka" {
  name   = "smartkhet-kafka-sg"
  vpc_id = aws_vpc.main.id
  ingress {
    from_port       = 9094
    to_port         = 9094
    protocol        = "tcp"
    security_groups = [aws_security_group.eks_nodes.id]
  }
  egress { from_port = 0; to_port = 0; protocol = "-1"; cidr_blocks = ["0.0.0.0/0"] }
}

resource "aws_security_group" "eks_nodes" {
  name   = "smartkhet-eks-nodes-sg"
  vpc_id = aws_vpc.main.id
  ingress { from_port = 0; to_port = 0; protocol = "-1"; self = true }
  egress  { from_port = 0; to_port = 0; protocol = "-1"; cidr_blocks = ["0.0.0.0/0"] }
}


# ── IAM Roles ─────────────────────────────────────────────────────────────────

resource "aws_iam_role" "eks_cluster" {
  name = "smartkhet-eks-cluster-role"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{ Action = "sts:AssumeRole"
                   Effect = "Allow"
                   Principal = { Service = "eks.amazonaws.com" } }]
  })
}

resource "aws_iam_role_policy_attachment" "eks_cluster_policy" {
  role       = aws_iam_role.eks_cluster.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKSClusterPolicy"
}

resource "aws_iam_role" "eks_node" {
  name = "smartkhet-eks-node-role"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{ Action = "sts:AssumeRole"
                   Effect = "Allow"
                   Principal = { Service = "ec2.amazonaws.com" } }]
  })
}

resource "aws_iam_role_policy_attachment" "eks_worker_node_policy" {
  role       = aws_iam_role.eks_node.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKSWorkerNodePolicy"
}

resource "aws_iam_role_policy_attachment" "eks_cni_policy" {
  role       = aws_iam_role.eks_node.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKS_CNI_Policy"
}

resource "aws_iam_role_policy_attachment" "ecr_read_only" {
  role       = aws_iam_role.eks_node.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryReadOnly"
}


# ── Outputs ───────────────────────────────────────────────────────────────────

output "eks_cluster_endpoint" {
  value = aws_eks_cluster.main.endpoint
}

output "eks_cluster_name" {
  value = aws_eks_cluster.main.name
}

output "rds_cluster_endpoint" {
  value     = aws_rds_cluster.postgres.endpoint
  sensitive = true
}

output "redis_endpoint" {
  value     = aws_elasticache_replication_group.redis.primary_endpoint_address
  sensitive = true
}

output "kafka_bootstrap_brokers" {
  value     = aws_msk_cluster.kafka.bootstrap_brokers_tls
  sensitive = true
}

output "s3_images_bucket" {
  value = aws_s3_bucket.images.bucket
}
